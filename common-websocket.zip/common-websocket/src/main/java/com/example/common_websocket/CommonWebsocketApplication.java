package com.example.common_websocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonWebsocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonWebsocketApplication.class, args);
	}

}
