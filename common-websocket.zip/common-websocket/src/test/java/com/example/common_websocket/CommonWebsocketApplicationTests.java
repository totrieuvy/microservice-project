package com.example.common_websocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonWebsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
